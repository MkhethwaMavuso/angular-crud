For this project, I will demonstrate my ability to develop web applications
using the angular framework by implementing basic C-Create R-Read 
U-Update D-Delete (CRUD) functionality, along with Login and Logout 
user functions; using local storage or db.

To start the project run the following commands:
(1) Merge folders [part-1] and [part-2] into one folder 
(2) npm Install. 
(2) npm update. 
(3) npm start/ng serve 
 

